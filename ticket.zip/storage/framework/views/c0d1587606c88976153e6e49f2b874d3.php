<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <style>
        .Profile img {
            width: 50px; /* Adjust as needed */
            height: 50px; /* Adjust as needed */
            border-radius: 50%; /* Makes the image circular */
        }
        .Profile {
            display: flex;
    gap: 10px;
    flex-direction: column;
        }
        .comments h3 {
            display: flex;
            width: 100%;
        }

        .comments {
            background-color: #303f53;
    padding: 20px;
    border-radius: 10px;
    display: flex;
    flex-direction: column;
    gap: 10px;
        }





        .bubble {
  --r: 25px; /* the radius */
  --t: 30px; /* the size of the tail */
  
  max-width: 300px;
  padding: calc(2*var(--r)/3);
  -webkit-mask: 
    radial-gradient(var(--t) at var(--_d) 0,#0000 98%,#000 102%) 
      var(--_d) 100%/calc(100% - var(--r)) var(--t) no-repeat,
    conic-gradient(at var(--r) var(--r),#000 75%,#0000 0) 
      calc(var(--r)/-2) calc(var(--r)/-2) padding-box, 
    radial-gradient(50% 50%,#000 98%,#0000 101%) 
      0 0/var(--r) var(--r) space padding-box;
  color: #fff;
}
.left {
  --_d: 0%;
  border-left: var(--t) solid #0000;
  margin-right: var(--t);
  place-self: start;
  background-color: rgb(83, 79, 200);
}
.right {
  --_d: 100%;
  border-right: var(--t) solid #0000;
  margin-left: var(--t);
  place-self: end;
  background-color: rgb(176, 66, 66);
}

.form-control {
    width: 100%;
    padding: 10px;
    border-radius: 5px;
    border: 1px solid #ccc;
    margin-bottom: 10px;
    color: black;
}



    </style>

    <div class="Ticketcontent">
        <h1 style="font-weight: 700"><?php echo e($ticket->title); ?></h1>
        <h3><?php echo e($ticket->description); ?></h3><br>
        <button type="refresh" class="btn btn-primary" onclick="window.location.reload();">Refresh</button><br><br> <!-- Fixed closing tag -->
        
        <!-- Ticket details here -->

        <!-- List existing comments -->
        <div class="comments">
            <?php
                $loggedInUserId = Auth::user()->id; // Assuming you have the Auth facade
            ?>
            <?php $__currentLoopData = $ticket->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $messageClass = $comment->user->id === $loggedInUserId ? 'right' : 'left';
                ?>






                <div class="bubble <?php echo e($messageClass); ?>">
                    <div class="Profile">
                        <img src='<?php echo e(Storage::url($comment->user->profilepicture)); ?>' :value="old('profilepicture', $comment->user->profilepicture)" required autofocus autocomplete="profilepicture" /></img>
                        <h1 style="font-size: 15px; font-weight: 700;"><?php echo e($comment->user->name); ?><br> 
                        <?php echo e($comment->user->role->name ?? 'No Role'); ?><br> <!-- Adjusted to display role -->
                        <?php echo e($comment->created_at->format('H:i d M Y')); ?></h1>
                    <p><?php echo e($comment->body); ?></p>
                    <?php if($comment->image_path): ?> <!-- Check if there's an image -->
                    <img src="<?php echo e(Storage::url($comment->image_path)); ?>" style="    max-width: 300px !important; max-height: 300px !important; border-radius: 10px !important; min-height: 100px !important; min-width: 100px !important;">
                <?php endif; ?>
                </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <form method="POST" action="<?php echo e(route('comments.store')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <textarea name="body" class="form-control"></textarea>
                <input type="hidden" name="ticket_id" id="ticket_id" value="<?php echo e($ticket->id); ?>" />
                <input type="file" name="image" class="form-control"> <!-- Image upload input -->
                <br>
                <button type="submit" class="btn btn-primary">Submit Comment</button>
                 
            </form>
            	
        </div> 
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ticket\resources\views/tickets/show.blade.php ENDPATH**/ ?>